To run this, open up the project file "Untitled Project 1" and click the run button in the taskbar. Then see the front panel window and enjoy the show.

The on/off switch toggles the filter, and the numeric selector allows you to set the lower cutoff frequency (in Hz). If you terminate the simulation you can see the data in the array.

The roll and pitch were calculated using the fact that there is a point of reference that is always 1g, such that pitch = arcsin(g_y) and roll = arcsin(g_x). This was implemented using the built-in arcsin block.

Raquel Charron 260588791

Marc Cataford 260517747

Drifa Bellache 260587257


Link to video: https://drive.google.com/open?id=1-M7P8evYbZ6LlQWs9ROb3_nQeoq2uBMQ